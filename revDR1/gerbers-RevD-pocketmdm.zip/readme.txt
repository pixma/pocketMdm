README
===
##PCB Specs
- Double Side PCB
- Insulation Material height(Important): 20 mil( Differential Pair Lines are there for 100ohm and 90 Ohm controlled impedance )
- Silk Color: White
- Solder Mask Color: Green
- Surface treatment: HASL
- finished copper thickness: 1oz
- Board Thickness: Will Depend on Insulation Material, rest may be normal.

Board size 50x50 mm only | Expecting 10 Qty PCB.
Would like to go for Free Shipping to India
